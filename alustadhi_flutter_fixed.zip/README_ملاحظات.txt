1) استبدل pubspec.yaml و lib/main.dart و assets/index.html و .github/workflows/build.yml في مشروعك.
2) في android/app/src/main/AndroidManifest.xml أضف قبل <application>:
   <uses-permission android:name="android.permission.INTERNET"/>
   <uses-permission android:name="android.permission.CAMERA"/>
   <uses-permission android:name="android.permission.RECORD_AUDIO"/>
3) إذا كان اسم الحزمة في مشروعك مختلفاً عن "alustadhi" فغيّر name: في pubspec.yaml وأي import يخصه.
4) إذا فشل pub get مرة ثانية انسخ الأسطر التي قبل "Process completed with exit code 1".
